﻿using System.IO;
using System.Reflection;
using Newtonsoft.Json;

namespace CovHx.ClaimsApi.Tests.Integration.Resources
{
    public static class ResourceContent
    {
        public static object GetPolicy(string policy)
        {
            return GetResource("Policy", policy);
        }

        public static object GetClaim(string claim)
        {
            return GetResource("Claim", claim);
        }

        private static object GetResource(string resourceType, string fileName)
        {
            var assembly = Assembly.GetExecutingAssembly();
            var jsonPath = $"CovHx.ClaimsApi.Tests.Integration.Resources.{resourceType}.{fileName}.json";
            var json = assembly.GetManifestResourceStream(jsonPath);
            string jsonString;
            using (var sr = new StreamReader(json))
            {
                jsonString = sr.ReadToEnd();
            }

            return JsonConvert.DeserializeObject(jsonString);
        }
    }
}
