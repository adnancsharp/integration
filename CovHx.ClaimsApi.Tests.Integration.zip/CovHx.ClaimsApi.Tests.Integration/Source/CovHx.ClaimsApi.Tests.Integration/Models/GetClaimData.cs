﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CovHx.ClaimsApi.Tests.Integration.Models
{
    public class GetClaimData
    {
        public string ClaimId { get; set; }
        public int ClaimYear { get; set; }
        public int Sequence { get; set; }
    }
}
