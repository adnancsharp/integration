﻿namespace CovHx.ClaimsApi.Tests.Integration
{
    public class Config
    {
        public const string DateTimeFormat = "yyyy-MM-ddTHH:mm:ssZ";
    }
}
