﻿using System;
using System.Net;
using CovHx.ClaimsApi.Tests.Integration.Resources;
using NUnit.Framework;
using TechTalk.SpecFlow;
using System.Configuration;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;

namespace CovHx.ClaimsApi.Tests.Integration.StepDefinitions
{
    [Binding]
    public class PostClaimSteps
    {
        private dynamic PolicyJson { get; set; }
        private dynamic ClaimJson { get; set; }
        private int PostedPolicyNumber { get; set; }
        private string PostedClaimId { get; set; }

        private static string InceptionDate => DateTime.Now.AddMonths(-2).ToString(Config.DateTimeFormat);
        private static string IncidentDate => DateTime.Now.AddDays(-10).ToString(Config.DateTimeFormat);
        private static string NotificationDate => DateTime.Now.AddDays(-8).ToString(Config.DateTimeFormat);
    
        private string PolicyServiceBaseUrl = ConfigurationManager.AppSettings["PolicyServiceBaseUrl"];

        private string ClaimsServiceBaseUrl = ConfigurationManager.AppSettings["ClaimsServiceBaseUrl"];


        [Given(@"I have a policy '(.*)'")]
        public void GivenIHaveAPolicy(string policy)
        {
            PolicyJson = ResourceContent.GetPolicy(policy);
            PolicyJson.PolicyDetails.InceptionDate = InceptionDate;
        }

        [Given(@"the policy has been created")]
        public void GivenThePolicyHasBeenCreated()
        {
            var url = $"{PolicyServiceBaseUrl}/CreatePolicy";
            var result = HttpWrapper.Post(url, PolicyJson);

            Assert.That(result.StatusCode, Is.EqualTo(HttpStatusCode.OK));
            PostedPolicyNumber = HttpWrapper.GetResponseObject(result).PolicyNumber;
        }

        [Given(@"the policy brand is (.*)")]
        public void GivenThePolicyBrandIs(string policyBrand)
        {
            PolicyJson.PolicyDetails.Brand = policyBrand;
        }

        [Given(@"I have a claim '(.*)'")]
        public void GivenIHaveAClaim(string claim)
        {
            ClaimJson = ResourceContent.GetClaim(claim);
            ClaimJson.Claim.IncidentDateTime = IncidentDate;
            ClaimJson.Claim.NotificationDateTime = NotificationDate;
            ClaimJson.Claim.Policy.PolicyNumber = PostedPolicyNumber;
        }

        [Given(@"the last driver type is (.*)")]
        public void GivenTheLastDriverTypeIs(string driverType)
        {
            ClaimJson.LastDriver.Type = driverType;
        }

        [Given(@"the claim has been posted")]
        public void GivenIHavePostedAClaim()
        {
            PostClaim();
        }

        [Given(@"the incident type is (.*)")]
        public void GivenTheIncidentTypeIs(string incidentType)
        {
            if (incidentType != "Accident")
            {
                ClaimJson.Claim.Incident.Remove("Accident");
            }

            if (incidentType == "Theft")
            {
                ClaimJson.Claim.Incident.Theft = new
                {
                    Recovered = true,
                    CollisionType = "Storm Damage",
                    WeatherConditions = "Dry - Sunny",
                    RoadType = "Dual Carriageway",
                    RoadConditions = "Dry",
                    Visibility = "Clear - Day"
                };
            }
            ClaimJson.Claim.ClaimType = incidentType;
        }

        [Given(@"the injury is (.*)")]
        public void GivenTheInjuryIs(string injury)
        {
            ClaimJson.Injury = injury;
        }

        [Given(@"the NCD disallowed is (.*)")]
        public void GivenTheNCDIs(string ncd)
        {
            ClaimJson.NcdDisallowed = ncd;
        }

        [Given(@"the User Indemnity is (.*)")]
        public void GivenTheUserIndemnityIs(string userIndemnity)
        {
            ClaimJson.UserIndemnity = userIndemnity;
        }

        [Given(@"the PoliceAttended is (.*)")]
        public void GivenThePoliceAttended(string policeAttended)
        {
            ClaimJson.Claim.PoliceAttended = policeAttended;
        }

        [Given(@"the Accident is (.*) and (.*)")]
        public void GivenTheAccidentIs(string accident, string type)
        {
            if (type.Equals("Null"))
            {
                type = null; //set to null in json without string type
            }
            
            switch (accident)
            {
                case "Collision":
                    ClaimJson.Claim.Incident.Accident.CollisionType = type;
                    break;
                case "Weather Conditions":
                    ClaimJson.Claim.Incident.Accident.WeatherConditions = type;
                    break;
                case "Road Type":
                    ClaimJson.Claim.Incident.Accident.RoadType = type;
                    break;
                case "Road Conditions":
                    ClaimJson.Claim.Incident.Accident.RoadConditions = type;
                    break;
                case "Visibility":
                    ClaimJson.Claim.Incident.Accident.Visibility = type;
                    break;
            } 
        }

        [Given(@"the Claimant type is (.*)")]
        public void GivenTheClaimantTypeIs(string claimantType)
        {  
        }

        [Given(@"the IsDriveable value is (.*)")]
        public void GivenTheIsDriveableValueIs(string isDriveable)
        {
            if (isDriveable.Equals("Null"))
            {
                isDriveable = null; //set to null in json without string type
            }
            ClaimJson.Claim.ClaimParticipants[0].Vehicle.IsDriveable = isDriveable;
        }

        [Given(@"the address is '(.*)' '(.*)' '(.*)' '(.*)' '(.*)' '(.*)' '(.*)'")]
        public void GivenTheAddressIs(string address1, string address2, string address3, string address4, string postcode, string country, string nameOrNumber)
        {
            ClaimJson.Claim.IncidentLocation.NameOrNumber = (nameOrNumber != "Null") ? nameOrNumber : null;
            ClaimJson.Claim.IncidentLocation.Address1 = (address1 != "Null") ? address1 : null;
            ClaimJson.Claim.IncidentLocation.Address2 = (address2 != "Null") ? address2 : null;
            ClaimJson.Claim.IncidentLocation.Address3 = (address3 != "Null") ? address3 : null;
            ClaimJson.Claim.IncidentLocation.Address4 = (address4 != "Null") ? address4 : null;
            ClaimJson.Claim.IncidentLocation.Postcode = (postcode != "Null") ? postcode : null;
            ClaimJson.Claim.IncidentLocation.Country = (country != "Null") ? country : null;
        }

        [When(@"I post the claim")]
        public void WhenIPostANewClaim()
        {
            PostClaim();
        }

        [Then(@"I should get a claim id returned")]
        public void ThenIShouldGetAClaimReferenceReturned()
        {
            Assert.That(string.IsNullOrEmpty(PostedClaimId), Is.False);
        }
        
        private void PostClaim()
        {
            var url = $"{ClaimsServiceBaseUrl}/api/v1/claims";

            var result = HttpWrapper.Post(url, ClaimJson);

            Assert.That(result.StatusCode, Is.EqualTo(HttpStatusCode.Created));
            var postedClaim = HttpWrapper.GetResponseObject(result);

            PostedClaimId = postedClaim.ClaimId;
        }
    }
}
