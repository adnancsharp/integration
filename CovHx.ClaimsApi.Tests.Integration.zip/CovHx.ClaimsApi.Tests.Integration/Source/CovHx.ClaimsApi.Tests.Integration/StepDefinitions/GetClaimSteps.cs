﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Configuration;
using CovHx.ClaimsApi.Tests.Integration.Resources;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;
using CovHx.ClaimsApi.Tests.Integration.Models;

namespace CovHx.ClaimsApi.Tests.Integration.StepDefinitions
{
    [Binding]
    public class GetClaimSteps
    {
        private dynamic ClaimJson { get; set; }
        private dynamic Result { get; set; }
        private string ResponseClaimId { get; set; }
        private string ResponseClaimYear { get; set; }
        private string ResponseSequence { get; set; }

        //private GetClaimData _claimData;

        private string GetClaimUrl = ConfigurationManager.AppSettings["GetClaimUrl"];

        [Given(@"I get a claim with claimid (.*)")]
        public void IGetAClaim(string claimId)
        {
            var url = $"{GetClaimUrl}/{claimId}";

            Result = HttpWrapper.Get(url);
        }

        [When(@"a claim is returned")]
        [Then(@"a claim is returned")]
        public void IGetASuccessClaimReturned()
        {
            Assert.That(Result.StatusCode, Is.EqualTo(HttpStatusCode.OK));
        }

        [Then(@"the claim returned is correct (.*) (.*) (.*)")]
        public void TheClaimReturnedIsCorrect(string claimId, int claimYear, int sequence)
        {
            ResponseClaimId = HttpWrapper.GetResponseObject(Result).Claim.ClaimId;
            ResponseClaimYear = HttpWrapper.GetResponseObject(Result).Claim.ClaimYear;
            ResponseSequence = HttpWrapper.GetResponseObject(Result).Claim.Sequence;

            Assert.IsTrue(claimId == ResponseClaimId);
        }


    }
}
