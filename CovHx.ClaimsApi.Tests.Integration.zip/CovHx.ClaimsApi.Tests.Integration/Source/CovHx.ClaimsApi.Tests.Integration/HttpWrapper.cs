﻿using System;
using System.Net.Http;
using Newtonsoft.Json;

namespace CovHx.ClaimsApi.Tests.Integration
{
    public class HttpWrapper
    {
        public static HttpResponseMessage Post(string url, object json)
        {
            var result = GetClient().PostAsync(url, new JsonContent(json)).Result;
            return result;
        }

        public static HttpResponseMessage Get(string url)
        {
            return GetClient().GetAsync(url).Result;
        }

        public static object GetResponseObject(HttpResponseMessage response)
        {
            var result = response.Content.ReadAsStringAsync().Result;
            return JsonConvert.DeserializeObject(result);
        }

        private static HttpClient GetClient()
        {
            var client = new HttpClient();
            client.DefaultRequestHeaders.Add("X-Covea-Sender-Username", "API_AUTOMATION");
            client.DefaultRequestHeaders.Add("X-Covea-Send-DateTime", DateTime.Now.ToString(Config.DateTimeFormat));

            return client;
        }
    }
}
